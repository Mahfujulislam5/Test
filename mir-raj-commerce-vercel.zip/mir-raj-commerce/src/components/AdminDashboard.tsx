 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type Product = {id:string;nameEn:string;nameBn:string;descriptionEn:string;descriptionBn:string;category:string;price:number;stock:number;imageUrl:string;active:boolean;createdAt:string;updatedAt:string};
type Item = {id:string;productNameEn:string;productNameBn:string;unitPrice:number;quantity:number};
type Order = {id:string;orderNumber:string;customerName:string;phone:string;address:string;note:string;subtotal:number;deliveryFee:number;total:number;status:string;createdAt:string;items:Item[]};
const blank = {nameEn:"",nameBn:"",descriptionEn:"",descriptionBn:"",category:"Accessories",price:0,stock:0,imageUrl:"",active:true};
const money = (n:number)=>new Intl.NumberFormat("en-BD",{style:"currency",currency:"BDT",maximumFractionDigits:0}).format(n);
const statuses = ["PENDING","CONFIRMED","PROCESSING","SHIPPED","DELIVERED","CANCELLED"];

export default function AdminDashboard({products:initialProducts,orders:initialOrders,revenue,pendingOrders}:{products:Product[];orders:Order[];revenue:number;pendingOrders:number}) {
  const [products,setProducts] = useState(initialProducts);
  const [orders,setOrders] = useState(initialOrders);
  const [form,setForm] = useState<typeof blank>(blank);
  const [editing,setEditing] = useState<string|null>(null);
  const [tab,setTab] = useState<"orders"|"products">("orders");
  const [message,setMessage] = useState("");
  const [error,setError] = useState("");
  const [busy,setBusy] = useState(false);
  const router = useRouter();
  async function saveProduct(e:React.FormEvent) {
    e.preventDefault(); setBusy(true);setMessage("");setError("");
    try {
      const url = editing ? `/api/admin/products/${editing}` : "/api/admin/products";
      const res = await fetch(url,{method:editing?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...form,price:Number(form.price),stock:Number(form.stock)})});
      const data=await res.json(); if(!res.ok) throw new Error(data.error||"Could not save product.");
      setMessage(editing?"Product updated.":"Product created."); setForm(blank);setEditing(null);router.refresh();
      // Refresh from the server so the admin table always reflects persisted data.
      window.location.reload();
    } catch(err){setError(err instanceof Error?err.message:"Save failed");} finally{setBusy(false);}
  }
  function editProduct(p:Product) {setEditing(p.id);setForm({nameEn:p.nameEn,nameBn:p.nameBn,descriptionEn:p.descriptionEn,descriptionBn:p.descriptionBn,category:p.category,price:p.price,stock:p.stock,imageUrl:p.imageUrl,active:p.active});window.scrollTo({top:0,behavior:"smooth"});}
  async function updateStatus(orderId:string,status:string) {
    setError("");setMessage("");
    try {
      const res=await fetch(`/api/admin/orders/${orderId}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})});
      const data=await res.json();if(!res.ok)throw new Error(data.error||"Status update failed.");
      setOrders(prev=>prev.map(o=>o.id===orderId?{...o,status}:o));setMessage("Order status updated.");
      if(status==="CANCELLED") window.location.reload();
    }catch(err){setError(err instanceof Error?err.message:"Update failed");}
  }
  async function logout(){await fetch("/api/admin/logout",{method:"POST"});router.push("/admin/login");router.refresh();}
  return <main className="admin-shell"><div className="admin-top"><div className="wrap admin-nav"><a className="brand" href="/"><span className="logo">MR</span><span>MIR RAJ<small style={{color:"#b8c0cc"}}>ADMIN PANEL</small></span></a><div style={{display:"flex",gap:10,alignItems:"center"}}><a className="btn lime" href="/" target="_blank">View store ↗</a><button className="btn outline" onClick={logout}>Log out</button></div></div></div>
  <div className="wrap admin-content"><div className="section-head"><div><div className="kicker">STORE MANAGEMENT</div><h2>Dashboard</h2><p className="muted">Manage your catalogue and customer orders.</p></div></div>
    <div className="admin-grid"><div className="metric"><small>Total products</small><strong>{products.length}</strong></div><div className="metric"><small>Total orders loaded</small><strong>{orders.length}</strong></div><div className="metric"><small>Pending orders</small><strong>{pendingOrders}</strong></div><div className="metric"><small>Non-cancelled order value</small><strong>{money(revenue)}</strong></div></div>
    {message&&<div className="toast">{message}</div>}{error&&<div className="toast error">{error}</div>}
    <div className="admin-card"><div className="admin-tabs"><a className={tab==="orders"?"active":""} href="#orders" onClick={e=>{e.preventDefault();setTab("orders")}}>Orders</a><a className={tab==="products"?"active":""} href="#products" onClick={e=>{e.preventDefault();setTab("products")}}>Products</a></div>
    {tab==="orders"?<><h3 id="orders">Recent orders</h3>{orders.length===0?<p className="muted">No orders have been placed yet.</p>:<table className="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Update</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td><b>{o.orderNumber}</b><div className="small">{new Date(o.createdAt).toLocaleString()}</div></td><td>{o.customerName}<div className="small">{o.phone}</div><div className="small">{o.address}</div></td><td>{o.items.map(i=><div key={i.id}>{i.productNameEn} × {i.quantity}</div>)}</td><td><b>{money(o.total)}</b></td><td><span className={`status ${o.status}`}>{o.status}</span></td><td><select className="admin-input" value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}>{statuses.map(s=><option key={s}>{s}</option>)}</select></td></tr>)}</tbody></table>}</>:<><h3>{editing?"Edit product":"Add a product"}</h3><form className="admin-form" onSubmit={saveProduct}><label className="field">Name (English)<input className="admin-input" required value={form.nameEn} onChange={e=>setForm({...form,nameEn:e.target.value})}/></label><label className="field">Name (বাংলা)<input className="admin-input" required value={form.nameBn} onChange={e=>setForm({...form,nameBn:e.target.value})}/></label><label className="field">Category<input className="admin-input" required value={form.category} onChange={e=>setForm({...form,category:e.target.value})}/></label><label className="field">Price (BDT)<input className="admin-input" type="number" min="0" required value={form.price} onChange={e=>setForm({...form,price:Number(e.target.value)})}/></label><label className="field">Stock<input className="admin-input" type="number" min="0" required value={form.stock} onChange={e=>setForm({...form,stock:Number(e.target.value)})}/></label><label className="field">Image URL (optional)<input className="admin-input" type="url" value={form.imageUrl} onChange={e=>setForm({...form,imageUrl:e.target.value})}/></label><label className="field">Description (English)<input className="admin-input" value={form.descriptionEn} onChange={e=>setForm({...form,descriptionEn:e.target.value})}/></label><label className="field">Description (বাংলা)<input className="admin-input" value={form.descriptionBn} onChange={e=>setForm({...form,descriptionBn:e.target.value})}/></label><label className="field">Visible in store<select className="admin-input" value={String(form.active)} onChange={e=>setForm({...form,active:e.target.value==="true"})}><option value="true">Yes</option><option value="false">No</option></select></label><div style={{display:"flex",gap:8,alignItems:"end",flexWrap:"wrap"}}><button className="btn" disabled={busy}>{busy?"Saving...":editing?"Save changes":"Add product"}</button>{editing&&<button className="btn outline" type="button" onClick={()=>{setEditing(null);setForm(blank)}}>Cancel edit</button>}</div></form><h3 style={{marginTop:28}}>Product catalogue</h3><table className="admin-table"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Visible</th><th>Action</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td><b>{p.nameEn}</b><div className="small">{p.nameBn}</div></td><td>{p.category}</td><td>{money(p.price)}</td><td>{p.stock}</td><td>{p.active?"Yes":"No"}</td><td><button className="btn outline" onClick={()=>editProduct(p)}>Edit</button></td></tr>)}</tbody></table></>}</div>
    <p className="note">Security note: keep admin credentials and environment variables private. Configure backups and test order cancellation/stock handling before accepting live orders.</p>
  </div></main>;
}
