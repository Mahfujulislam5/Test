 "use client";

import { useMemo, useState } from "react";
import { messages, type Locale } from "@/lib/i18n";

type Product = { id: string; nameEn: string; nameBn: string; descriptionEn: string; descriptionBn: string; category: string; price: number; stock: number; imageUrl: string };
type CartItem = { product: Product; quantity: number };

const icons: Record<string,string> = { Audio:"🎧", Accessories:"🔌", Mobile:"📱", "Smart gadgets":"⌚" };
const money = (n: number, locale: Locale) => new Intl.NumberFormat(locale === "bn" ? "bn-BD" : "en-BD", { style:"currency", currency:"BDT", maximumFractionDigits:0 }).format(n);

export default function Storefront({ products }: { products: Product[] }) {
  const [locale, setLocale] = useState<Locale>("bn");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customer, setCustomer] = useState({ customerName:"", phone:"", address:"", note:"" });
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const t = messages[locale];
  const categories = ["all", ...Array.from(new Set(products.map(p => p.category)))];
  const visible = useMemo(() => products.filter(p => (category === "all" || p.category === category) && `${p.nameEn} ${p.nameBn} ${p.category}`.toLowerCase().includes(query.toLowerCase())), [products, category, query]);
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const add = (product: Product) => {
    if (product.stock < 1) return;
    setCart(prev => {
      const found = prev.find(item => item.product.id === product.id);
      if (found) return prev.map(item => item.product.id === product.id ? { ...item, quantity: Math.min(item.quantity + 1, product.stock) } : item);
      return [...prev, { product, quantity: 1 }];
    });
    setNotice(locale === "bn" ? "পণ্য কার্টে যোগ হয়েছে।" : "Product added to cart.");
    setError("");
  };
  const changeQty = (id: string, delta: number) => setCart(prev => prev.map(item => item.product.id === id ? { ...item, quantity: Math.min(item.product.stock, item.quantity + delta) } : item).filter(item => item.quantity > 0));
  const order = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/orders", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ ...customer, locale, items:cart.map(item => ({ productId:item.product.id, quantity:item.quantity })) }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not place order.");
      setNotice(`${t.orderSuccess} ${t.orderNumber}: ${data.orderNumber}`);
      const phone = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "";
      if (phone && !phone.includes("X")) {
        const text = `MIR RAJ order ${data.orderNumber}\nName: ${customer.customerName}\nPhone: ${customer.phone}\nTotal: ${money(data.total, locale)}\nPlease confirm my order.`;
        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
      }
      setCart([]);
      setCustomer({ customerName:"", phone:"", address:"", note:"" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally { setBusy(false); }
  };
  const wa = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "";
  const waUrl = wa && !wa.includes("X") ? `https://wa.me/${wa}?text=${encodeURIComponent("Hello MIR RAJ! I have a question about your products.")}` : "#contact";
  return <>
    <div className="topbar">SMART TECH. FAIR PRICES. <b>ORDER WITH MIR RAJ</b></div>
    <header><div className="wrap nav">
      <a className="brand" href="#home"><span className="logo">MR</span><span>MIR RAJ<small>TECH STORE · BANGLADESH</small></span></a>
      <nav className="navlinks"><a href="#home">{t.home}</a><a href="#products">{t.products}</a><a href="#about">{t.about}</a><a href="#contact">{t.contact}</a></nav>
      <div style={{display:"flex",gap:8,alignItems:"center"}}><button className="btn outline" onClick={() => setLocale(locale === "bn" ? "en" : "bn")}>{t.language}</button><a className="btn" href="#cart">{t.cart} ({cart.reduce((n,i)=>n+i.quantity,0)})</a></div>
    </div></header>
    <main>
      <section className="hero" id="home"><div className="wrap hero-grid"><div><span className="eyebrow">✦ {t.eyebrow}</span><h1>{t.headlineA}<br/><span>{t.headlineB}</span></h1><p>{t.intro}</p><div className="actions"><a className="btn" href="#products">{t.shopNow} ↓</a><a className="btn lime" href={waUrl} target={waUrl.startsWith("https") ? "_blank" : undefined} rel="noreferrer">{t.chat} ↗</a></div></div><div className="hero-art"><span className="art-label">TECH THAT FITS YOUR LIFE</span><div className="gadgets">📱 🎧 ⌚</div></div></div></section>
      <section className="features"><div className="wrap feature-grid"><div className="feature"><span>💬</span>{locale==="bn"?"সহজ অর্ডার":"Simple ordering"}<small>{locale==="bn"?"সরাসরি WhatsApp-এ":"Direct WhatsApp support"}</small></div><div className="feature"><span>🎧</span>{locale==="bn"?"দৈনন্দিন গ্যাজেট":"Everyday essentials"}<small>{locale==="bn"?"দরকারি প্রযুক্তি পণ্য":"Useful tech products"}</small></div><div className="feature"><span>🤝</span>{locale==="bn"?"সহায়ক সেবা":"Friendly support"}<small>{locale==="bn"?"কেনার আগে জেনে নিন":"Ask before you buy"}</small></div><div className="feature"><span>🇧🇩</span>{locale==="bn"?"বাংলাদেশের জন্য":"Made for Bangladesh"}<small>{locale==="bn"?"স্থানীয় গ্রাহক সেবা":"Local customer service"}</small></div></div></section>
      <section className="section" id="products"><div className="wrap"><div className="section-head"><div><div className="kicker">MIR RAJ COLLECTION</div><h2>{t.popular}</h2><p className="muted">{locale==="bn"?"পণ্য বেছে নিন, কার্টে যোগ করুন এবং অর্ডার দিন।":"Choose products, add to cart and place your order."}</p></div></div>
      <div className="searchbar"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t.search}/><div className="filters">{categories.map(c=><button key={c} className={`filter ${category===c?"active":""}`} onClick={()=>setCategory(c)}>{c==="all"?t.all:c}</button>)}</div></div>
      <div className="product-grid">{visible.map(p=><article className="product" key={p.id}><div className="product-visual"><span className="stocktag">{p.stock>0?`${p.stock} ${t.stock}`:(locale==="bn"?"স্টক শেষ":"Out of stock")}</span>{p.imageUrl?<img src={p.imageUrl} alt={locale==="bn"?p.nameBn:p.nameEn} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<span>{icons[p.category]||"💻"}</span>}</div><div className="product-info"><div className="category">{p.category}</div><h3>{locale==="bn"?p.nameBn:p.nameEn}</h3><p>{locale==="bn"?p.descriptionBn:p.descriptionEn}</p><div className="buyrow"><div className="price">{money(p.price,locale)}<div className="small">{t.price}</div></div><button className="add" disabled={p.stock<1} onClick={()=>add(p)}>{p.stock>0?`+ ${t.add}`:(locale==="bn"?"স্টক শেষ":"Sold out")}</button></div></div></article>)}{visible.length===0&&<div className="empty">{t.noProducts}</div>}</div>
      <p className="note">{t.sample}</p>
      <div className="cartbox" id="cart"><div className="section-head"><div><div className="kicker">{t.checkout}</div><h2>{t.cart} ({cart.reduce((n,i)=>n+i.quantity,0)})</h2></div></div>
        {cart.length===0?<p className="muted">{t.emptyCart}</p>:<>{cart.map(item=><div className="cartrow" key={item.product.id}><div><b>{locale==="bn"?item.product.nameBn:item.product.nameEn}</b><div className="small">{money(item.product.price,locale)} × {item.quantity}</div></div><div style={{display:"flex",alignItems:"center",gap:9}}><button className="filter" onClick={()=>changeQty(item.product.id,-1)} aria-label="Decrease quantity">−</button><b>{item.quantity}</b><button className="filter" onClick={()=>changeQty(item.product.id,1)} aria-label="Increase quantity">+</button></div></div>)}<div className="cartrow"><span>{t.subtotal}</span><b>{money(subtotal,locale)}</b></div><div className="cartrow"><span>{t.delivery}</span><span>{locale==="bn"?"ঠিকানা অনুযায়ী নিশ্চিত হবে":"Confirmed based on address"}</span></div><div className="cartrow"><b>{t.total}</b><b>{money(subtotal,locale)} + {locale==="bn"?"ডেলিভারি":"delivery"}</b></div>
        <form onSubmit={order} style={{marginTop:20}}><div className="formgrid"><label className="field">{t.name}<input required minLength={2} value={customer.customerName} onChange={e=>setCustomer({...customer,customerName:e.target.value})}/></label><label className="field">{t.phone}<input required minLength={8} value={customer.phone} onChange={e=>setCustomer({...customer,phone:e.target.value})} inputMode="tel"/></label><label className="field full">{t.address}<textarea required minLength={8} rows={2} value={customer.address} onChange={e=>setCustomer({...customer,address:e.target.value})}/></label><label className="field full">{t.note}<textarea rows={2} value={customer.note} onChange={e=>setCustomer({...customer,note:e.target.value})}/></label></div><div className="actions"><button className="btn" type="submit" disabled={busy||cart.length===0}>{busy?(locale==="bn"?"অর্ডার হচ্ছে...":"Placing order..."):t.placeOrder}</button></div></form></>}
        {notice&&<div className="toast">{notice}</div>}{error&&<div className="toast error">{error}</div>}
      </div></div></section>
      <section className="banner"><div className="wrap"><div className="bannerbox"><div><h2>{locale==="bn"?"গ্যাজেট বাছাই করতে সাহায্য লাগবে?":"Need help choosing a gadget?"}</h2><p>{locale==="bn"?"আপনার প্রয়োজন জানান, আমরা সাহায্য করব।":"Tell us what you need and we will help."}</p></div><a className="btn lime" href={waUrl} target={waUrl.startsWith("https")?"_blank":undefined} rel="noreferrer">{t.chat} ↗</a></div></div></section>
      <section className="about" id="about"><div className="wrap about-grid"><div><div className="kicker">ABOUT MIR RAJ</div><h2>{t.aboutTitle}</h2><p>{t.aboutText}</p><a className="btn" href="#contact">{t.contact} ↗</a></div><div className="about-card"><div className="stat"><strong>{locale==="bn"?"সহজ":"Easy"}</strong><small>{locale==="bn"?"অর্ডার প্রক্রিয়া":"Order process"}</small></div><div className="stat"><strong>{locale==="bn"?"দরকারি":"Useful"}</strong><small>{locale==="bn"?"দৈনন্দিন প্রযুক্তি":"Everyday tech"}</small></div><div className="stat"><strong>{locale==="bn"?"স্থানীয়":"Local"}</strong><small>{locale==="bn"?"বাংলাদেশে সেবা":"Bangladesh service"}</small></div><div className="stat"><strong>{locale==="bn"?"সরাসরি":"Direct"}</strong><small>{locale==="bn"?"দোকানের সাথে কথা":"Talk to the store"}</small></div></div></div></section>
      <section className="contact" id="contact"><div className="wrap section-head"><div><div className="kicker">LET'S TALK</div><h2>{t.contactTitle}</h2><p className="muted">{locale==="bn"?"পণ্য, দাম বা স্টক জানতে আমাদের মেসেজ দিন।":"Message us about products, prices or availability."}</p></div><a className="btn" href={waUrl} target={waUrl.startsWith("https")?"_blank":undefined} rel="noreferrer">{t.chat} ↗</a></div></section>
    </main>
    <footer><div className="wrap"><div className="footer-top"><div className="brand"><span className="logo">MR</span><span>MIR RAJ<small style={{color:"#aeb7c5"}}>TECH STORE · BANGLADESH</small></span></div><div className="footer-links"><a href="#home">{t.home}</a><a href="#products">{t.products}</a><a href="#about">{t.about}</a><a href="/admin/login">Admin</a></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} MIR RAJ. All rights reserved.</span><span>{t.footer}</span></div></div></footer>
  </>;
}
