import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/auth";

const schema = z.object({ status: z.enum(["PENDING","CONFIRMED","PROCESSING","SHIPPED","DELIVERED","CANCELLED"]) });

export async function PATCH(request: Request, context: { params: Promise<{id:string}> }) {
  if (!await getAdminSession()) return NextResponse.json({ error:"Unauthorized" }, { status:401 });
  try {
    const { id } = await context.params;
    const { status } = schema.parse(await request.json());
    const order = await prisma.$transaction(async tx => {
      const current = await tx.order.findUnique({ where:{id}, include:{items:true} });
      if (!current) throw new Error("Order not found.");
      if (current.status === "CANCELLED" && status !== "CANCELLED") throw new Error("Cancelled orders cannot be reopened here.");
      if (status === "CANCELLED" && current.status !== "CANCELLED") {
        for (const item of current.items) if (item.productId) await tx.product.update({ where:{id:item.productId}, data:{stock:{increment:item.quantity}} });
      }
      return tx.order.update({ where:{id}, data:{status} });
    });
    return NextResponse.json({ order });
  } catch (error) {
    return NextResponse.json({ error:error instanceof Error ? error.message : "Could not update order." }, { status:400 });
  }
}
