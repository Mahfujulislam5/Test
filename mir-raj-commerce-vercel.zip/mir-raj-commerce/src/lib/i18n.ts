export type Locale = "bn" | "en";
export const messages = {
  bn: {
    home: "হোম", products: "পণ্যসমূহ", about: "আমাদের সম্পর্কে", contact: "যোগাযোগ",
    eyebrow: "আপনার দৈনন্দিন প্রযুক্তির ঠিকানা", headlineA: "স্মার্ট টেক।", headlineB: "আরও সহজ জীবন।",
    intro: "MIR RAJ-এ খুঁজুন দরকারি প্রযুক্তি পণ্য, মোবাইল অ্যাক্সেসরিজ ও স্মার্ট গ্যাজেট। পছন্দের পণ্য বেছে নিন, সহজেই অর্ডার করুন।",
    shopNow: "পণ্য দেখুন", chat: "WhatsApp-এ কথা বলুন", popular: "জনপ্রিয় পণ্য", search: "পণ্য খুঁজুন...",
    all: "সব পণ্য", add: "কার্টে যোগ করুন", cart: "কার্ট", checkout: "অর্ডার করুন", price: "দাম",
    aboutTitle: "প্রযুক্তি কেনাকাটা, আরও সহজ", aboutText: "MIR RAJ বাংলাদেশের গ্রাহকদের জন্য দরকারি প্রযুক্তি পণ্য ও দৈনন্দিন অ্যাক্সেসরিজ খুঁজে পাওয়ার সহজ একটি অনলাইন শপ।",
    contactTitle: "MIR RAJ-এর সাথে যোগাযোগ করুন", name: "আপনার নাম", phone: "মোবাইল নম্বর", address: "সম্পূর্ণ ঠিকানা", note: "অতিরিক্ত তথ্য (ঐচ্ছিক)",
    placeOrder: "অর্ডার নিশ্চিত করুন", emptyCart: "আপনার কার্ট খালি।", subtotal: "পণ্যের মোট", delivery: "ডেলিভারি চার্জ", total: "সর্বমোট",
    orderSuccess: "অর্ডার গ্রহণ করা হয়েছে!", orderNumber: "আপনার অর্ডার নম্বর", stock: "স্টক", noProducts: "কোনো পণ্য পাওয়া যায়নি।",
    footer: "স্মার্ট প্রযুক্তি, প্রতিদিনের জন্য।", language: "English", sample: "ডেমো পণ্য: প্রকৃত দাম ও স্টক নিশ্চিত করুন।"
  },
  en: {
    home: "Home", products: "Products", about: "About us", contact: "Contact",
    eyebrow: "Your everyday tech destination", headlineA: "Good tech.", headlineB: "Better living.",
    intro: "Discover useful tech essentials, mobile accessories and smart gadgets at MIR RAJ. Choose your favourite product and order with ease.",
    shopNow: "Explore products", chat: "Chat on WhatsApp", popular: "Popular products", search: "Search products...",
    all: "All products", add: "Add to cart", cart: "Cart", checkout: "Checkout", price: "Price",
    aboutTitle: "Tech shopping, made simple", aboutText: "MIR RAJ is an online shop concept for customers in Bangladesh looking for useful tech products and everyday accessories.",
    contactTitle: "Contact MIR RAJ", name: "Your name", phone: "Mobile number", address: "Full address", note: "Additional note (optional)",
    placeOrder: "Place order", emptyCart: "Your cart is empty.", subtotal: "Subtotal", delivery: "Delivery fee", total: "Total",
    orderSuccess: "Order received!", orderNumber: "Your order number", stock: "In stock", noProducts: "No products found.",
    footer: "Smart tech for everyday life.", language: "বাংলা", sample: "Demo products: confirm real prices and stock."
  }
} as const;
